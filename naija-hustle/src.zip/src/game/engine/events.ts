/** One dice roll at the start of every red light. 1-2 bad, 3-4 normal, 5-6 good. */
export type RoundEventKind = "normal" | "rain" | "lastma" | "sun" | "goslow";
export type RoundEvent = { die: number; kind: RoundEventKind; title: string; text: string; good: boolean };

const pick = <T,>(a: T[]) => a[Math.floor(Math.random() * a.length)];

const BAD: Omit<RoundEvent, "die">[] = [
  { kind: "lastma", title: "LASTMA!", text: "Task force grabs 2 items from your tray.", good: false },
  { kind: "rain", title: "Rain dey fall", text: "Windows go up. Fewer people will buy.", good: false },
];
const NORMAL: Omit<RoundEvent, "die">[] = [
  { kind: "normal", title: "Normal hustle", text: "Nothing special. Work the light.", good: false },
];
const GOOD: Omit<RoundEvent, "die">[] = [
  { kind: "sun", title: "Hot sun", text: "Everybody wants water and cold drinks.", good: true },
  { kind: "goslow", title: "Go-slow", text: "Traffic is stuck. The light runs 6 seconds longer.", good: true },
];

export function rollRoundEvent(): RoundEvent {
  const die = 1 + Math.floor(Math.random() * 6);
  const pool = die <= 2 ? BAD : die <= 4 ? NORMAL : GOOD;
  return { die, ...pick(pool) };
}
